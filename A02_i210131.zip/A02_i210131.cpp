#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <sstream>
#include <cstdlib>
#include <bits/stdc++.h> 
using namespace std;
union val 
{
long lval;
float fval;
};
struct record
{
short ID;
char name[50];
union val ageorweight; 
};
struct record r[1000];
string val;
int i=0;
void print_file()
{   
    ifstream rdata;
	rdata.open("data.txt",ios::app);
	string val;
	
	while(rdata.eof())
	{
	    getline(rdata,val,',');
	    stringstream temp(val);
	    temp>>r[i].ID;
	    cout<<r[i].ID<<" ";
	    getline(rdata,val,',');
    	strcpy(r[i].name, val.c_str()); 
		cout << r[i].name<<" ";
	    getline(rdata,val);
	    if (val.find('.') != std::string::npos)
	    {	
	    	r[i].ageorweight.fval= ::atof(val.c_str());   
			cout<<r[i].ageorweight.fval<<endl; 
		}		
		else
		{
			 
			long temp=::atof(val.c_str());
			r[i].ageorweight.lval= temp/12;
			cout<<r[i].ageorweight.lval<<endl;	
		}
	    i++;
    }
    rdata.close();
    }
void add_record()
{
	ofstream rdata;
	rdata.open("data.txt",ios::app);
	string val;
int n;
cout<<"Enter the number of people who showed up on test day \n";
cin>>n;
for(int i=0;i<n;i++)
{
cout<<"enter ID \n";
cin>>r[i].ID;
rdata<<r[i].ID<<","<<" ";
cout<<"Enter name \n";
cin>>r[i].name;
rdata<<r[i].name<<","<<" ";
float p,kg;
cout<<"Enter your weight in pounds: \n";
cin>>p;
kg=p*0.45359237;
cout<<"Your weight in Kilograms is: \n";
cout<<kg;
rdata<<kg<<","<<" ";
cout<<endl;
int years,days,months;
cout<<"Enter your age in years: \n";
cin>>years;
months=years*12;
cout<<"months"<<endl;
cout<<months<<endl;
rdata<<months<<","<<" ";
rdata<<endl;


 rdata.close();
}
}
void delete_record()
{
	string r[i];
	cout<<"Enter the record ID you want to delete: \n ";
    cin>>r[i];
    ifstream rdata("data.txt");
    if(!rdata.is_open())
    {
    	cout<<"File could not open. \n";
	}
	while(getline(rdata,r[i]))
	{
		if((r[i]=r[i].find(r[i]),0==0))
		{
			cout<<r[i]<<"\n";
		}
	}
	if((r[i]=r[i].find(r[i]),0)!=0)
	{
		cout<<r[i]<<"NOT FOUND"<<endl;
	}
 } 
 void edit_record()
 {
 	ofstream rdata("data.txt",ios::app);
 	if(!rdata)
 	{
 		cout<<"File could not open \n";
 		exit(1);
	 }
	int choice,na,d;
	cout<<"What do you want to edit?  \n";
	cout<<"1. Name: \n";
	cout<<"2. ID: \n";
	cin>>choice;
	if(choice==1)
	{
		cout<<"Enter new name \n";
		cin>>na;
	}
	if(choice==2)
	{
		cout<<"Enter new ID \n";
		cin>>d;
	}
 }
 
 
void search_ID(int a)
{
    ifstream rdata;
	rdata.open("data.txt",ios::out);
	string val;
	
	for(int j=0; j<i; j++)
	{
	    getline(rdata,val,',');
	    stringstream temp(val);
	    temp>>r[j].ID;
	    
	    
	    getline(rdata,val,',');
    	strcpy(r[j].name, val.c_str()); 
	
				
	    getline(rdata,val);
	    if (val.find('.') != std::string::npos)
	    {	
	    	r[j].ageorweight.fval= ::atof(val.c_str());   
	    	if(a==r[j].ID)
			cout<<r[j].ID<<" "<< r[j].name<< " "<< r[j].ageorweight.fval<<" Kgs"<<endl;
	
		}
	    		
		else
		{
			long temp=::atof(val.c_str());
			r[j].ageorweight.lval= temp/12;
			if(a==r[j].ID)
			cout<<r[j].ID<<" "<< r[j].name<< " "<< r[j].ageorweight.lval<<" yrs"<<endl;	
		}
    }
    rdata.close();
}
	

void search_Name(char a[50])
{
	cout<<a;
	ifstream rdata;
	rdata.open("data.txt",ios::out);
	string val;
	for(int j=0; j<i; j++)
	{
	    getline(rdata,val,',');
	    stringstream temp(val);
	    temp>>r[j].ID;
	    getline(rdata,val,',');
    	strcpy(r[j].name, val.c_str()); 
	    getline(rdata,val);
	    if (val.find('.')!= std::string::npos)
	    {	
	    	r[j].ageorweight.fval= ::atof(val.c_str());   
	    	if( !strcmp( a, r[j].name ))
			cout<<r[j].ID<<" "<< r[j].name<< " "<< r[j].ageorweight.fval<<" Kgs"<<endl;
	
		}		
		else
		{
			 
			long temp=::atof(val.c_str());
			r[j].ageorweight.lval= temp/12;
			if( !strcmp( a, r[j].name ))
			cout<<r[j].ID<<" "<< r[j].name<< " "<< r[j].ageorweight.lval<<" yrs"<<endl;
			
		}
	    
	   
    }
    rdata.close();
}		
void menu()
{
	cout<<"WELCOME TO CONTACT BOOK"<<endl;
	cout<<"Select option:"<<endl;
	cout<<"1. Search"<<endl;
	cout<<"2. Edit"<<endl;
	cout<<"3. Add record"<<endl;
	cout<<"4. Delete record"<<endl;
	int a;
	cin>>a;
	cout<<endl;
	switch(a)
	{
			case 1:
				cout<<"1. Search by ID"<<endl;
				cout<<"2. Search by name"<<endl;
				cin>>a;
				if(a==1)
				{
					cout<<"Enter ID:";
					cin>>a;
					search_ID(a);	
				}
				else if(a==2)
				{
					cout<<"Enter name:";
					char n[50];
					cin>>n;
					search_Name(n);
				}
				break;
				case 2:
					{
						edit_record();
					}
					case 3:
						{
							add_record();
							break;
						}
						case 4:
							{
								delete_record();
							}
							
	}
	
}  
int main()
{
	for(int k=0;k<4;k++)
{
  cout<<"All Entries"<<endl;
  print_file();
  menu(); 
}
}
